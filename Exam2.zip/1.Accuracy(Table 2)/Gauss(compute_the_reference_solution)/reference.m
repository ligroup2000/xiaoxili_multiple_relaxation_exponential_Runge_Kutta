function Un_t_f=reference(tau)

N=40;  T=1;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p; 

w1=1/8-sqrt(30)/144;  w2=0.5*sqrt((15+2*sqrt(30))/35);  w3=w2*(1/6+sqrt(30)/24); 
w4=w2*(1/21+5*sqrt(30)/168);  w5=w2-2*w3;
w11=1/8+sqrt(30)/144;  w22=0.5*sqrt((15-2*sqrt(30))/35);  w33=w22*(1/6-sqrt(30)/24); 
w44=w22*(1/21-5*sqrt(30)/168);  w55=w22-2*w33;
A=[w1 w11-w3+w44 w11-w3-w44 w1-w5; ... 
   w1-w33+w4 w11 w11-w55 w1-w33-w4; ...
   w1+w33+w4 w11+w55 w11 w1+w33-w4; ...
   w1+w5 w11+w3+w44 w11+w3-w44 w1];
b=[2*w1 2*w11 2*w11 2*w1];
 
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0; 
Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un);  Un_t_f=Un_t(:);

L_f=spdiags(L(:),0,N^2,N^2);  s=size(A,1);  es=ones(s,1);  Matrix=(speye(s*N^2)-tau*kron(A,L_f))^(-1);

for k=1:round(T/tau)
    iter_err=1;  iter_count=0;  Ue=kron(es,Un_t_f);  Umid_t_f=Ue;
    while ((iter_err>10^(-14)) && (iter_count<100))
        Umid_t=reshape(Umid_t_f,N,N,s);  Umid=ifftcoe*ifft2(Umid_t);  
        gmid_t=fftcoe*fft2(1i*(f(abs(Umid).^2).*Umid));
        v1=tau*reshape(gmid_t,N^2,s)*(A');
        vec=Ue+v1(:);
        Umid_t_f_save=Umid_t_f;  Umid_t_f=Matrix*vec;
        iter_err=max(abs(Umid_t_f_save-Umid_t_f));
        iter_count=iter_count+1;
    end
    Umid_t=reshape(Umid_t_f,N,N,s);  Umid=ifftcoe*ifft2(Umid_t);  
    gmid_t=fftcoe*fft2(1i*(f(abs(Umid).^2).*Umid));
    Un_t_f=Un_t_f+tau*L_f*reshape(Umid_t,N^2,s)*(b')+tau*reshape(gmid_t,N^2,s)*(b');
    tn=tn+tau
end