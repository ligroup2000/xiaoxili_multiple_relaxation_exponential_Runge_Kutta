function [err,gamma1_average,gamma2_average,gamma_average, ...
          S1_average,S2_average,S_average, ...
          det_B_save,Iter,tmesh]=MRERK4(tau)

N=40;  T=1;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  area=(Re-Le)^2;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0;  Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un);
Gamma1=[];  Gamma2=[];  tmesh=[];  det_B_save=[];  Iter=[];
S1=[];  S2=[]; 

c2=0.5;  c3=0.5;  c4=1;
tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;  tauL4=c4*tauL;
tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;  tauL4(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
phi3=((exp(tauL)-1-tauL-0.5*tauL.^2)./(tauL.^3));  phi3(1,1)=1/6;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  tauL3  %%%%
phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
%%%%  tauL4  %%%%
phi14=(exp(tauL4)-1)./(tauL4);  phi14(1,1)=1;
phi24=((exp(tauL4)-1-tauL4)./(tauL4.^2));  phi24(1,1)=1/2;
%%%%  coe_matrix %%%%
A21=0.5*phi12;
A31=0.5*phi13-0.5*phi23;  A32=0.5*phi23;
A41=phi14-2*phi24;  A42=-2*phi24;  A43=4*phi24;
B1=phi1-3*phi2+4*phi3;  B2=zeros(N,1);  B3=4*phi2-8*phi3;  B4=-phi2+4*phi3;

while (tn<(T-tau))
    %%%% Un1_t
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t
    Un1=ifftcoe*ifft2(Un1_t);  Gn1_t=fftcoe*fft2(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Un3_t
    Un2=ifftcoe*ifft2(Un2_t);  Gn2_t=fftcoe*fft2(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
    %%%% Un4_t
    Un3=ifftcoe*ifft2(Un3_t);  Gn3_t=fftcoe*fft2(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
    Un4_t=Un_t+tau*A41.*GLUn1_t+tau*A42.*GLUn2_t+tau*A43.*GLUn3_t;
    %%%% Unew_t
    Un4=ifftcoe*ifft2(Un4_t);  Gn4_t=fftcoe*fft2(1i*(f(abs(Un4).^2).*Un4));  GLUn4_t=Gn4_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t+tau*B4.*GLUn4_t;  d1=ifftcoe*ifft2(d1_t); 
    d2_t=tau*phi1.*GLUn4_t;  d2=ifftcoe*ifft2(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft2(Unew_t);
    energy1=area*real(sum(sum(conj(Un_t).*Un_t)));  
    energy2=-area*real(sum(sum(conj(Un_t).*Kxxyy.*Un_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Un_t))).^2)));  
    energy1_new=area*real(sum(sum(conj(Unew_t).*Unew_t)));  
    energy2_new=-area*real(sum(sum(conj(Unew_t).*Kxxyy.*Unew_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Unew_t))).^2)));  
    S1=[S1 abs(energy1-energy1_new)];  S2=[S2 abs(energy2-energy2_new)];  tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0;];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(sum(conjUnew_t.*Unew_t)))-energy1;  
        Unewd1=area*real(sum(sum(conjUnew_t.*d1_t)));  
        Unewd2=area*real(sum(sum(conjUnew_t.*d2_t)));
        d1d1=area*real(sum(sum(conjd1.*d1_t)));   
        d2d2=area*real(sum(sum(conjd2.*d2_t))); 
        d1d2=area*real(sum(sum(conjd1.*d2_t))); 
        UnewKUn=-area*real(sum(sum(conjUnew_t.*Kxxyy.*Unew_t)))-energy2;
        UnewKd1=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d1_t)));  
        UnewKd2=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d2_t)));
        d1Kd1=-area*real(sum(sum(conjd1.*Kxxyy.*d1_t)));   
        d2Kd2=-area*real(sum(sum(conjd2.*Kxxyy.*d2_t))); 
        d1Kd2=-area*real(sum(sum(conjd1.*Kxxyy.*d2_t))); 
        [gamma,iter_count]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
        fUnew=f(abs(Unew).^2).*Unew;
        result=det([(2/tau/tau)*Unewd1 (2/tau/tau)*Unewd2; ...
                    (2/tau/tau)*UnewKd1-(2/tau/tau)*real(h*h*sum(sum(fUnew.*conj(d1)))) ...
                    (2/tau/tau)*UnewKd2-(2/tau/tau)*real(h*h*sum(sum(fUnew.*conj(d2))))]);
        det_B_save=[det_B_save result];
        Iter=[Iter iter_count];
    end
    fprintf('tn=%d,gamma1=%d,gamma2=%d\n',tn,abs(gamma(1)),abs(gamma(2)));
    Gamma1=[Gamma1 gamma(1)];  Gamma2=[Gamma2 gamma(2)];
    %%%% step update %%%%
    Un_t_save=Un_t;  tn_save=tn;
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
end
tmesh=[tmesh tn];

if ( (T-tn)<=0 )
    Gamma1=Gamma1(1:end-1);  Gamma2=Gamma2(1:end-1);  S1=S1(1:end-1);  S2=S2(1:end-1);  tmesh=tmesh(1:end-1);
    Un_t=Un_t_save;  tn=tn_save;  tau=T-tn;
else
    tau=T-tn;
end
tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;  tauL4=c4*tauL;
tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;  tauL4(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
phi3=((exp(tauL)-1-tauL-0.5*tauL.^2)./(tauL.^3));  phi3(1,1)=1/6;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  tauL3  %%%%
phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
%%%%  tauL4  %%%%
phi14=(exp(tauL4)-1)./(tauL4);  phi14(1,1)=1;
phi24=((exp(tauL4)-1-tauL4)./(tauL4.^2));  phi24(1,1)=1/2;
%%%%  coe_matrix %%%%
A21=0.5*phi12;
A31=0.5*phi13-0.5*phi23;  A32=0.5*phi23;
A41=phi14-2*phi24;  A42=-2*phi24;  A43=4*phi24;
B1=phi1-3*phi2+4*phi3;  B2=zeros(N,1);  B3=4*phi2-8*phi3;  B4=-phi2+4*phi3;
%%%% Un1_t
LUn_t=L.*Un_t;  Un1_t=Un_t;
%%%% Un2_t
Un1=ifftcoe*ifft2(Un1_t);  Gn1_t=fftcoe*fft2(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
Un2_t=Un_t+tau*A21.*GLUn1_t;
%%%% Un3_t
Un2=ifftcoe*ifft2(Un2_t);  Gn2_t=fftcoe*fft2(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
%%%% Un4_t
Un3=ifftcoe*ifft2(Un3_t);  Gn3_t=fftcoe*fft2(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
Un4_t=Un_t+tau*A41.*GLUn1_t+tau*A42.*GLUn2_t+tau*A43.*GLUn3_t;
%%%% Unew_t
Un4=ifftcoe*ifft2(Un4_t);  Gn4_t=fftcoe*fft2(1i*(f(abs(Un4).^2).*Un4));  GLUn4_t=Gn4_t+LUn_t;
d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t+tau*B4.*GLUn4_t;  Un_t=Un_t+d1_t;  tn=tn+tau;

load reference.mat
err=max(abs(Un_t(:)-Un_t_f_10000));
gamma1_average=mean(abs(Gamma1));
gamma2_average=mean(abs(Gamma2));
gamma_average=mean([gamma1_average gamma2_average]);
S1_average=mean(abs(S1));
S2_average=mean(abs(S2));
S_average=mean([S1_average S2_average]);