% stepsize=[1/160 1/320 1/640 1/1280];  % MRERK2
% stepsize=[1/80 1/160 1/320 1/640];  % MRERK3
stepsize=[1/20 1/40 1/80 1/160];  % MRERK4
Err=[];  
Gamma1_average=[];  Gamma2_average=[];  Gamma_average=[];  
S1=[];  S2=[];  S=[];  
for k=1:size(stepsize,2)
    [err,gamma1_average,gamma2_average,gamma_average, ...
     S1_average,S2_average,S_average, ...
     det_B_save,Iter,tmesh]=MRERK4(stepsize(k));  % choose the method
    Err=[Err err];
    Gamma1_average=[Gamma1_average gamma1_average];
    Gamma2_average=[Gamma2_average gamma2_average];
    Gamma_average=[Gamma_average gamma_average];
    S1=[S1 S1_average];
    S2=[S2 S2_average];
    S=[S S_average];
    eval(['DET.stepsize',num2str(k),'=det_B_save;']);
    eval(['ITER.stepsize',num2str(k),'=Iter;']);
    eval(['TMESH.stepsize',num2str(k),'=tmesh;']);
end

Err_order=log(Err(1:end-1)./Err(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma1_order=log(Gamma1_average(1:end-1)./Gamma1_average(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma2_order=log(Gamma2_average(1:end-1)./Gamma2_average(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
Gamma_order=log(Gamma_average(1:end-1)./Gamma_average(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S1_order=log(S1(1:end-1)./S1(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S2_order=log(S2(1:end-1)./S2(2:end))./log(stepsize(1:end-1)./stepsize(2:end))
S_order=log(S(1:end-1)./S(2:end))./log(stepsize(1:end-1)./stepsize(2:end))