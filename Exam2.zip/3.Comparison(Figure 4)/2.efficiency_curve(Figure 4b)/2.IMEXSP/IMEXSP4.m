function [err,energy1_average,energy2_average,time]=IMEXSP4(tau)
tic;
N=40;  T=1;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  area=(Re-Le)^2;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0; 
Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un);
Energy1=[];  Energy2=[];

Ai=[0 0 0 0 0 0; ... 
    0 1/2 0 0 0 0; ...
    1/4 -1/4 1/2 0 0 0; ...
    0 1 0 0 0 0; ...
    1/6 0 2/3 -4/3 3/2 0; ...
    1/6 0 2/3 1/6 -2 2;];
Ae=[0 0 0 0 0 0; ...
    1/2 0 0 0 0 0; ...
    1/4 1/4 0 0 0 0; ...
    0 -1 2 0 0 0; ...
    1/6 0 2/3 1/6 0 0; ...
    1/6 0 2/3 1/6 0 0;];
Matrix1=(ones(N,N)-tau*0.5*L).^(-1);  Matrix2=(ones(N,N)-tau*(3/2)*L).^(-1);  Matrix3=(ones(N,N)-tau*2*L).^(-1);
s=size(Ai,2);

Umid=zeros(N,N,s);  F1mid=zeros(N,N,s);  F2mid=zeros(N,N,s);  
for k=1:round(T/tau)
    Umid(:,:,1)=Un_t;  
    F1mid(:,:,1)=L.*Umid(:,:,1);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,1));  F2mid(:,:,1)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,:,1:1);  F1midp=reshape(tau*reshape(F1midp,N^2,1)*(Ai(2,1:1))',N,N);
    F2midp=F2mid(:,:,1:1);  F2midp=reshape(tau*reshape(F2midp,N^2,1)*(Ae(2,1:1))',N,N);
    Umid(:,:,2)=Matrix1.*(Un_t+F1midp+F2midp);
    F1mid(:,:,2)=L.*Umid(:,:,2);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,2));  F2mid(:,:,2)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,:,1:2);  F1midp=reshape(tau*reshape(F1midp,N^2,2)*(Ai(3,1:2))',N,N);
    F2midp=F2mid(:,:,1:2);  F2midp=reshape(tau*reshape(F2midp,N^2,2)*(Ae(3,1:2))',N,N);
    Umid(:,:,3)=Matrix1.*(Un_t+F1midp+F2midp);
    F1mid(:,:,3)=L.*Umid(:,:,3);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,3));  F2mid(:,:,3)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,:,1:3);  F1midp=reshape(tau*reshape(F1midp,N^2,3)*(Ai(4,1:3))',N,N);
    F2midp=F2mid(:,:,1:3);  F2midp=reshape(tau*reshape(F2midp,N^2,3)*(Ae(4,1:3))',N,N);
    Umid(:,:,4)=Un_t+F1midp+F2midp;
    F1mid(:,:,4)=L.*Umid(:,:,4);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,4));  F2mid(:,:,4)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,:,1:4);  F1midp=reshape(tau*reshape(F1midp,N^2,4)*(Ai(5,1:4))',N,N);
    F2midp=F2mid(:,:,1:4);  F2midp=reshape(tau*reshape(F2midp,N^2,4)*(Ae(5,1:4))',N,N);
    Umid(:,:,5)=Matrix2.*(Un_t+F1midp+F2midp);
    F1mid(:,:,5)=L.*Umid(:,:,5);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,5));  F2mid(:,:,5)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,:,1:5);  F1midp=reshape(tau*reshape(F1midp,N^2,5)*(Ai(6,1:5))',N,N);
    F2midp=F2mid(:,:,1:5);  F2midp=reshape(tau*reshape(F2midp,N^2,5)*(Ae(6,1:5))',N,N);
    Umid(:,:,6)=Matrix3.*(Un_t+F1midp+F2midp);
    F1mid(:,:,6)=L.*Umid(:,:,6);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,6));  F2mid(:,:,6)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    Unew_t=Umid(:,:,end);  
    energy1=area*real(sum(sum(conj(Un_t).*Un_t)));  
    energy2=-area*real(sum(sum(conj(Un_t).*Kxxyy.*Un_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Un_t))).^2)));  
    Energy1=[Energy1 energy1];  Energy2=[Energy2 energy2];
    %%%% step update %%%%
    Un_t=Unew_t;  tn=tn+tau;
end

toc;
time=toc;
energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
energy2_average=mean(abs(Energy2-Energy2(1))./abs(Energy2(1)));
load reference.mat  
err=max(abs(Un_t(:)-Un_t_f_10000));