function [err,energy1_average,energy2_average,time]=IMEXSP3(tau)
tic;
N=40;  T=1;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  area=(Re-Le)^2;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0; 
Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un);
Energy1=[];  Energy2=[];

coe_gamma=1767732205903/4055673282236;
Ai=[0 0 0 0; ...
    1767732205903/4055673282236 coe_gamma 0 0; ...
    2746238789719/10658868560708 -640167445237/6845629431997 coe_gamma 0; ...
    1471266399579/7840856788654 -4482444167858/7529755066697 11266239266428/11593286722821 coe_gamma];
bi1=[1471266399579/7840856788654 -4482444167858/7529755066697 11266239266428/11593286722821 1767732205903/4055673282236];
Ae=[0 0 0 0; ...
    1767732205903/2027836641118 0 0 0; ...
    5535828885825/10492691773637 788022342437/10882634858940 0 0; ...
    6485989280629/16251701735622 -4246266847089/9704473918619 10755448449292/10357097424841 0];
be1=[1471266399579/7840856788654 -4482444167858/7529755066697 11266239266428/11593286722821 1767732205903/4055673282236];
Matrix=(ones(N,1)-tau*coe_gamma*L).^(-1);  s=size(Ai,2);

Umid=zeros(N,N,s);  F1mid=zeros(N,N,s);  F2mid=zeros(N,N,s); 
for k=1:round(T/tau)
    Umid(:,:,1)=Un_t;  
    F1mid(:,:,1)=L.*Umid(:,:,1);  
    Umid_temp=ifftcoe*ifft2(Umid(:,:,1));  F2mid(:,:,1)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    for kk=2:s
        F1midp=F1mid(:,:,1:kk-1);  F1midp=reshape(tau*reshape(F1midp,N^2,kk-1)*(Ai(kk,1:kk-1))',N,N);
        F2midp=F2mid(:,:,1:kk-1);  F2midp=reshape(tau*reshape(F2midp,N^2,kk-1)*(Ae(kk,1:kk-1))',N,N);
        Umid(:,:,kk)=Matrix.*(Un_t+F1midp+F2midp);
        F1mid(:,:,kk)=L.*Umid(:,:,kk);  
        Umid_temp=ifftcoe*ifft2(Umid(:,:,kk));  F2mid(:,:,kk)=fftcoe*fft2(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    end
    d1_t=reshape(tau*reshape(F1mid,N^2,s)*bi1',N,N)+reshape(tau*reshape(F2mid,N^2,s)*be1',N,N);
    Unew_t=Un_t+d1_t;  
    energy1=area*real(sum(sum(conj(Un_t).*Un_t)));  
    energy2=-area*real(sum(sum(conj(Un_t).*Kxxyy.*Un_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Un_t))).^2)));
    Energy1=[Energy1 energy1];  Energy2=[Energy2 energy2];
    %%%% step update %%%%
    Un_t=Unew_t;  tn=tn+tau;
end

toc;
time=toc;
energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
energy2_average=mean(abs(Energy2-Energy2(1))./abs(Energy2(1)));
load reference.mat  
err=max(abs(Un_t(:)-Un_t_f_10000));