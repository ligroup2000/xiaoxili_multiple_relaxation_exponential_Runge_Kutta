function [stepsize,tmesh]=MRERK2(tau)

N=40;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  area=(Re-Le)^2;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0; 
Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un);
stepsize=[];  tmesh=[];

c2=0.5;
tauL=tau*L;  tauL2=c2*tauL;
tauL(1)=1;  tauL2(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  coe_matrix %%%%
A21=c2*phi12;
B1=phi1-(1/c2)*phi2;  B2=(1/c2)*phi2;

for k=1:50
    %%%% Un1_t %%%%
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t %%%%
    Un1=ifftcoe*ifft2(Un1_t);  Gn1_t=fftcoe*fft2(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Unew_t %%%%
    Un2=ifftcoe*ifft2(Un2_t);  Gn2_t=fftcoe*fft2(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t;  d1=ifftcoe*ifft2(d1_t);
    d2_t=0.5*tau*phi1.*(GLUn1_t+GLUn2_t);  d2=ifftcoe*ifft2(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft2(Unew_t);
    energy1=area*real(sum(sum(conj(Un_t).*Un_t)));  
    energy2=-area*real(sum(sum(conj(Un_t).*Kxxyy.*Un_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Un_t))).^2)));    tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(sum(conjUnew_t.*Unew_t)))-energy1;  
        Unewd1=area*real(sum(sum(conjUnew_t.*d1_t)));  
        Unewd2=area*real(sum(sum(conjUnew_t.*d2_t)));
        d1d1=area*real(sum(sum(conjd1.*d1_t)));   
        d2d2=area*real(sum(sum(conjd2.*d2_t))); 
        d1d2=area*real(sum(sum(conjd1.*d2_t))); 
        UnewKUn=-area*real(sum(sum(conjUnew_t.*Kxxyy.*Unew_t)))-energy2;
        UnewKd1=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d1_t)));  
        UnewKd2=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d2_t)));
        d1Kd1=-area*real(sum(sum(conjd1.*Kxxyy.*d1_t)));   
        d2Kd2=-area*real(sum(sum(conjd2.*Kxxyy.*d2_t))); 
        d1Kd2=-area*real(sum(sum(conjd1.*Kxxyy.*d2_t))); 
        [gamma,~]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
    end
    stepsize=[stepsize (1+gamma(1)+gamma(2))*tau]; 
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
    k
end
plot(stepsize)
save('MRERK2.mat','stepsize','tmesh')