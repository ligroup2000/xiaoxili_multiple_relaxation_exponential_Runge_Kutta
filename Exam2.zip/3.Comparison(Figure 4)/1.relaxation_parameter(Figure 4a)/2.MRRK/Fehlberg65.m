function [stepsize,tmesh,Un_t]=Fehlberg65(tau)

N=40;  Le=0;  Re=2*pi;  p=4;  alpha=1; 
h=(Re-Le)/N;  area=(Re-Le)^2;  xmesh=Le:h:Re-h;  ymesh=xmesh;  [X,Y]=meshgrid(xmesh,ymesh);  
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N/N;  ifftcoe=N*N;
tn=0; 
Un=(1+0.01*sin(2*X+3*Y)).*exp(1i*(X+Y));
Un_t=fftcoe*fft2(Un); 
stepsize=[];  tmesh=[];


A=[0 0 0 0 0 0; ... 
   1/4 0 0 0 0 0; ...
   3/32 9/32 0 0 0 0; ...
   1932/2197 -7200/2197 7296/2197 0 0 0; ...
   439/216 -8 3680/513 -845/4104 0 0; ...
   -8/27 2 -3544/2565 1859/4104 -11/40 0];
b1=[16/135 0 6656/12825 28561/56430 -9/50 2/55];
b2=[25/216 0 1408/2565 2197/4104 -1/5 0];
s=size(A,2);

for k=1:50
    Umid=zeros(N,N,s);  Fmid=zeros(N,N,s);  
    Umid(:,:,1)=Un_t;  Un=ifftcoe*ifft2(Un_t);  Fmid(:,:,1)=L.*Un_t+fftcoe*fft2(1i*(f(abs(Un).^2).*Un));
    for kk=2:s
        Umid(:,:,kk)=Un_t+reshape(tau*reshape(Fmid(:,:,1:kk-1),N^2,kk-1)*(A(kk,1:kk-1))',N,N);
        Up=ifftcoe*ifft2(Umid(:,:,kk));
        Fmid(:,:,kk)=L.*Umid(:,:,kk)+fftcoe*fft2(1i*(f(abs(Up).^2).*Up));
    end
    d1_t=reshape(tau*reshape(Fmid,N^2,s)*b1',N,N);  d1=ifftcoe*ifft2(d1_t);
    d2_t=reshape(tau*reshape(Fmid,N^2,s)*b2',N,N);  d2=ifftcoe*ifft2(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft2(Unew_t);
    energy1=area*real(sum(sum(conj(Un_t).*Un_t)));  
    energy2=-area*real(sum(sum(conj(Un_t).*Kxxyy.*Un_t)))-h*h*sum(sum(F((abs(ifftcoe*ifft2(Un_t))).^2)));
    tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(sum(conjUnew_t.*Unew_t)))-energy1;  
        Unewd1=area*real(sum(sum(conjUnew_t.*d1_t)));  
        Unewd2=area*real(sum(sum(conjUnew_t.*d2_t)));
        d1d1=area*real(sum(sum(conjd1.*d1_t)));   
        d2d2=area*real(sum(sum(conjd2.*d2_t))); 
        d1d2=area*real(sum(sum(conjd1.*d2_t))); 
        UnewKUn=-area*real(sum(sum(conjUnew_t.*Kxxyy.*Unew_t)))-energy2;
        UnewKd1=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d1_t)));  
        UnewKd2=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d2_t)));
        d1Kd1=-area*real(sum(sum(conjd1.*Kxxyy.*d1_t)));   
        d2Kd2=-area*real(sum(sum(conjd2.*Kxxyy.*d2_t))); 
        d1Kd2=-area*real(sum(sum(conjd1.*Kxxyy.*d2_t))); 
        [gamma,~]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
    end
    stepsize=[stepsize (1+gamma(1)+gamma(2))*tau]; 
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
    k
end
plot(stepsize)
save('Fehlberg65.mat','stepsize','tmesh','tau','Un_t');