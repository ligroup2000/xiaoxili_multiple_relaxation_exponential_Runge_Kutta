function det_B=compute_det_B_MRERK2(Un_t)

N=40;  T=100;  Le=0;  Re=2*pi;  p=4;  alpha=0.1; 
h=(Re-Le)/N;  area=(Re-Le)^2; 
x_freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  y_freq=x_freq;  [X_freq,Y_freq]=meshgrid(x_freq,y_freq);
Kxxyy=(-1)*X_freq.^2+(-1)*Y_freq.^2;  L=1i*Kxxyy; 
f=@(x)alpha*x.^p;
fftcoe=1/N/N;  ifftcoe=N*N;

    tau=1/1000;
    
    c2=0.5;
    tauL=tau*L;  tauL2=c2*tauL;
    tauL(1)=1;  tauL2(1)=1;
    %%%%  tauL  %%%%
    phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
    phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
    %%%%  tauL2  %%%%
    phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
    %%%%  coe_matrix %%%%
    A21=c2*phi12;
    B1=phi1-(1/c2)*phi2;  B2=(1/c2)*phi2;
    
    %%%% Un1_t %%%%
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t %%%%
    Un1=ifftcoe*ifft2(Un1_t);  Gn1_t=fftcoe*fft2(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Unew_t %%%%
    Un2=ifftcoe*ifft2(Un2_t);  Gn2_t=fftcoe*fft2(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t;  d1=ifftcoe*ifft2(d1_t);
    d2_t=0.5*tau*phi1.*(GLUn1_t+GLUn2_t);  d2=ifftcoe*ifft2(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft2(Unew_t);
    
    conjUnew_t=conj(Unew_t); 
    Unewd1=area*real(sum(sum(conjUnew_t.*d1_t)));  
    Unewd2=area*real(sum(sum(conjUnew_t.*d2_t)));
    UnewKd1=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d1_t)));  
    UnewKd2=-area*real(sum(sum(conjUnew_t.*Kxxyy.*d2_t)));
    fUnew=f(abs(Unew).^2).*Unew;
    result=det([(2/tau/tau)*Unewd1 (2/tau/tau)*Unewd2; ...
                (2/tau/tau)*UnewKd1-(2/tau/tau)*real(h*h*sum(sum(fUnew.*conj(d1)))) ...
                (2/tau/tau)*UnewKd2-(2/tau/tau)*real(h*h*sum(sum(fUnew.*conj(d2))))]);
    
    det_B=result;
