function det_B=compute_det_B_MRERK3(Un_t)

N=2000;  Le=-100;  Re=100;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;
fftcoe=1/N;  ifftcoe=N;

    tau=1/1000;
    
    c2=0.5;  c3=2/3;
    tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;
    tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;
    %%%%  tauL  %%%%
    phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
    phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
    %%%%  tauL2  %%%%
    phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
    %%%%  tauL3  %%%%
    phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
    phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
    %%%%  coe_matrix %%%%
    A21=c2*phi12;
    A31=(2/3)*phi13-(4/9/c2)*phi23;  A32=(4/9/c2)*phi23;
    B1=phi1-(3/2)*phi2;  B2=zeros(N,1);  B3=(3/2)*phi2;
    
    %%%% Un1_t
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Un3_t
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
    %%%% Unew_t
    Un3=ifftcoe*ifft(Un3_t);  Gn3_t=fftcoe*fft(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t;  d1=ifftcoe*ifft(d1_t); 
    d2_t=(1/3)*tau*phi1.*(GLUn1_t+GLUn2_t+GLUn3_t);  d2=ifftcoe*ifft(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft(Unew_t);
    
    conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t); 
    Unewd1=area*real(sum(conjUnew_t.*d1_t));  Unewd2=area*real(sum(conjUnew_t.*d2_t));
    UnewKd1=-area*real(sum(conjUnew_t.*Kxx.*d1_t));  UnewKd2=-area*real(sum(conjUnew_t.*Kxx.*d2_t));
    fUnew=f(abs(Unew).^2).*Unew;
    result=det([(2/tau/tau)*Unewd1 (2/tau/tau)*Unewd2; ...
                (2/tau/tau)*UnewKd1-(2/tau/tau)*real(h*sum(fUnew.*conj(d1))) ...
                (2/tau/tau)*UnewKd2-(2/tau/tau)*real(h*sum(fUnew.*conj(d2)))]);
            
    det_B=result;