%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.2;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.22;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load('MRERK2.mat');
Energy_RERK22=Energy1;  tmesh_RERK22=tmesh;
load('MRERK3.mat');
Energy_RERK33=Energy1;  tmesh_RERK33=tmesh;
load('MRERK4.mat');
Energy_RERK44=Energy1;  tmesh_RERK44=tmesh;
load('ERK2.mat');
Energy_ERK22=Energy1;  tmesh_ERK22=tmesh;
load('ERK3.mat');
Energy_ERK33=Energy1;  tmesh_ERK33=tmesh;
load('ERK4.mat');
Energy_ERK44=Energy1;  tmesh_ERK44=tmesh;

semilogy(tmesh_ERK22,abs(Energy_ERK22-Energy_ERK22(1))/abs(Energy_ERK22(1)),':b','LineWidth',2);  hold on;
semilogy(tmesh_ERK33,abs(Energy_ERK33-Energy_ERK33(1))/abs(Energy_ERK33(1)),':g','LineWidth',2);
semilogy(tmesh_ERK44,abs(Energy_ERK44-Energy_ERK44(1))/abs(Energy_ERK44(1)),':r','LineWidth',2);
semilogy(tmesh_RERK22,abs(Energy_RERK22-Energy_RERK22(1))/abs(Energy_RERK22(1)),'b','LineWidth',2);  
semilogy(tmesh_RERK33,abs(Energy_RERK33-Energy_RERK33(1))/abs(Energy_RERK33(1)),'g','LineWidth',2);
semilogy(tmesh_RERK44,abs(Energy_RERK44-Energy_RERK44(1))/abs(Energy_RERK44(1)),'r','LineWidth',2); 

set(gca,'XLim',[0 100])
set(gca,'YLim',[10^(-16) 10^(-1)])
set(gca,'linewidth',2,'FontSize',24)
xlabel('$t$','interpreter','latex','FontSize',32)
ylabel('$DM^n$ or $DM_\gamma^n$','interpreter','latex','FontSize',32)
legend('ERK2','ERK3','ERK4','MRERK2','MRERK3','MRERK4')
set(legend,'interpreter','latex','location','east','FontSize',20) 