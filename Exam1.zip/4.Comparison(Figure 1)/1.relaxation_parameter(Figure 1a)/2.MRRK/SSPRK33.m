function [stepsize,tmesh,Un_t]=SSPRK33(tau)

N=500;  Le=-25;  Re=25;  p=1;  alpha=2; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  
Ue=@(t)sech(xmesh+4*t).*exp(-1i*(2*xmesh+3*t));
Un=Ue(tn);
Un_t=fftcoe*fft(Un); 
stepsize=[];  tmesh=[];


A=[0 0 0;1 0 0;1/4 1/4 0];
b1=[1/6 1/6 2/3];
b2=[0.291485418878409 0.291485418878409 0.417029162243181];
s=size(A,2);

for k=1:100
    Umid=zeros(N,s);  Fmid=zeros(N,s);  
    Umid(:,1)=Un_t;  Un=ifftcoe*ifft(Un_t);  Fmid(:,1)=L.*Un_t+fftcoe*fft(1i*(f(abs(Un).^2).*Un));
    for kk=2:s
        Umid(:,kk)=Un_t+tau*Fmid(:,1:kk-1)*(A(kk,1:kk-1))';
        Up=ifftcoe*ifft(Umid(:,kk));
        Fmid(:,kk)=L.*Umid(:,kk)+fftcoe*fft(1i*(f(abs(Up).^2).*Up));
    end
    d1_t=tau*Fmid*b1';  d1=ifftcoe*ifft(d1_t);
    d2_t=tau*Fmid*b2';  d2=ifftcoe*ifft(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft(Unew_t);
    energy1=area*real(sum(conj(Un_t).*Un_t));  
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));
    tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(conjUnew_t.*Unew_t))-energy1;  
        Unewd1=area*real(sum(conjUnew_t.*d1_t));  Unewd2=area*real(sum(conjUnew_t.*d2_t));
        d1d1=area*real(sum(conjd1.*d1_t));  d2d2=area*real(sum(conjd2.*d2_t));  d1d2=area*real(sum(conjd1.*d2_t));
        UnewKUn=-area*real(sum(conjUnew_t.*Kxx.*Unew_t))-energy2;
        UnewKd1=-area*real(sum(conjUnew_t.*Kxx.*d1_t));  UnewKd2=-area*real(sum(conjUnew_t.*Kxx.*d2_t));
        d1Kd1=-area*real(sum(conjd1.*Kxx.*d1_t));  d2Kd2=-area*real(sum(conjd2.*Kxx.*d2_t));  d1Kd2=-area*real(sum(conjd1.*Kxx.*d2_t));
        [gamma,~]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
    end
    stepsize=[stepsize (1+gamma(1)+gamma(2))*tau]; 
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
    k
end
plot(tmesh,stepsize)
save('SSPRK33.mat','stepsize','tmesh','tau','Un_t');