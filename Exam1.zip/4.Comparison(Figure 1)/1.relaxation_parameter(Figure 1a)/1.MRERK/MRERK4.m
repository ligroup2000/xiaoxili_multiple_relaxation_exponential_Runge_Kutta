function [stepsize,tmesh]=MRERK4(tau)

N=500;  Le=-25;  Re=25;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;
Ue=@(t)sech(xmesh+4*t).*exp(-1i*(2*xmesh+3*t));
Un=Ue(tn);
Un_t=fftcoe*fft(Un); 
stepsize=[];  tmesh=[];

c2=0.5;  c3=0.5;  c4=1;
tauL=tau*L;  tauL2=c2*tauL;  tauL3=c3*tauL;  tauL4=c4*tauL;
tauL(1)=1;  tauL2(1)=1;  tauL3(1)=1;  tauL4(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
phi3=((exp(tauL)-1-tauL-0.5*tauL.^2)./(tauL.^3));  phi3(1,1)=1/6;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  tauL3  %%%%
phi13=(exp(tauL3)-1)./(tauL3);  phi13(1,1)=1;
phi23=((exp(tauL3)-1-tauL3)./(tauL3.^2));  phi23(1,1)=1/2;
%%%%  tauL4  %%%%
phi14=(exp(tauL4)-1)./(tauL4);  phi14(1,1)=1;
phi24=((exp(tauL4)-1-tauL4)./(tauL4.^2));  phi24(1,1)=1/2;
%%%%  coe_matrix %%%%
A21=0.5*phi12;
A31=0.5*phi13-0.5*phi23;  A32=0.5*phi23;
A41=phi14-2*phi24;  A42=-2*phi24;  A43=4*phi24;
B1=phi1-3*phi2+4*phi3;  B2=zeros(N,1);  B3=4*phi2-8*phi3;  B4=-phi2+4*phi3;

for k=1:100
    %%%% Un1_t
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Un3_t
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    Un3_t=Un_t+tau*A31.*GLUn1_t+tau*A32.*GLUn2_t;
    %%%% Un4_t
    Un3=ifftcoe*ifft(Un3_t);  Gn3_t=fftcoe*fft(1i*(f(abs(Un3).^2).*Un3));  GLUn3_t=Gn3_t+LUn_t;
    Un4_t=Un_t+tau*A41.*GLUn1_t+tau*A42.*GLUn2_t+tau*A43.*GLUn3_t;
    %%%% Unew_t
    Un4=ifftcoe*ifft(Un4_t);  Gn4_t=fftcoe*fft(1i*(f(abs(Un4).^2).*Un4));  GLUn4_t=Gn4_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t+tau*B3.*GLUn3_t+tau*B4.*GLUn4_t;  d1=ifftcoe*ifft(d1_t); 
    d2_t=tau*phi1.*GLUn4_t;  d2=ifftcoe*ifft(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft(Unew_t);
    energy1=area*real(sum(conj(Un_t).*Un_t));
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(conjUnew_t.*Unew_t))-energy1;  
        Unewd1=area*real(sum(conjUnew_t.*d1_t));  Unewd2=area*real(sum(conjUnew_t.*d2_t));
        d1d1=area*real(sum(conjd1.*d1_t));  d2d2=area*real(sum(conjd2.*d2_t));  d1d2=area*real(sum(conjd1.*d2_t));
        UnewKUn=-area*real(sum(conjUnew_t.*Kxx.*Unew_t))-energy2;
        UnewKd1=-area*real(sum(conjUnew_t.*Kxx.*d1_t));  UnewKd2=-area*real(sum(conjUnew_t.*Kxx.*d2_t));
        d1Kd1=-area*real(sum(conjd1.*Kxx.*d1_t));  d2Kd2=-area*real(sum(conjd2.*Kxx.*d2_t));  d1Kd2=-area*real(sum(conjd1.*Kxx.*d2_t));
        [gamma,~]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
    end
    stepsize=[stepsize (1+gamma(1)+gamma(2))*tau]; 
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
    k
end

save('MRERK4.mat','stepsize','tmesh')