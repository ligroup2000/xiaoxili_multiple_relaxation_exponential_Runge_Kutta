function [stepsize,tmesh]=MRERK2(tau)

N=500;  Le=-25;  Re=25;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  
Ue=@(t)sech(xmesh+4*t).*exp(-1i*(2*xmesh+3*t));
Un=Ue(tn);
Un_t=fftcoe*fft(Un); 
stepsize=[];  tmesh=[];

c2=0.5;
tauL=tau*L;  tauL2=c2*tauL;
tauL(1)=1;  tauL2(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=((exp(tauL)-1-tauL)./(tauL.^2));  phi2(1,1)=1/2;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  coe_matrix %%%%
A21=c2*phi12;
B1=phi1-(1/c2)*phi2;  B2=(1/c2)*phi2;

for k=1:100
    %%%% Un1_t %%%%
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t %%%%
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Unew_t %%%%
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t;  d1=ifftcoe*ifft(d1_t);
    d2_t=0.5*tau*phi1.*(GLUn1_t+GLUn2_t);  d2=ifftcoe*ifft(d2_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft(Unew_t);
    energy1=area*real(sum(conj(Un_t).*Un_t));
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);
        UnewUn=area*real(sum(conjUnew_t.*Unew_t))-energy1;  
        Unewd1=area*real(sum(conjUnew_t.*d1_t));  Unewd2=area*real(sum(conjUnew_t.*d2_t));
        d1d1=area*real(sum(conjd1.*d1_t));  d2d2=area*real(sum(conjd2.*d2_t));  d1d2=area*real(sum(conjd1.*d2_t));
        UnewKUn=-area*real(sum(conjUnew_t.*Kxx.*Unew_t))-energy2;
        UnewKd1=-area*real(sum(conjUnew_t.*Kxx.*d1_t));  UnewKd2=-area*real(sum(conjUnew_t.*Kxx.*d2_t));
        d1Kd1=-area*real(sum(conjd1.*Kxx.*d1_t));  d2Kd2=-area*real(sum(conjd2.*Kxx.*d2_t));  d1Kd2=-area*real(sum(conjd1.*Kxx.*d2_t));
        [gamma,~]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2,UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2);
    end
    stepsize=[stepsize (1+gamma(1)+gamma(2))*tau]; 
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t;  tn=tn+(1+gamma(1)+gamma(2))*tau;
    k
end

save('MRERK2.mat','stepsize','tmesh')