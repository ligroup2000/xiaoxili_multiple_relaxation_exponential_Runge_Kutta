%% INPUT TIGHTPLOT PARAMETERS
TightPlot.ColumeNumber = 1;     % ��ͼ����
TightPlot.RowNumber = 1;    % ��ͼ����
TightPlot.GapW = 0.05;  % ��ͼ֮������Ҽ��
TightPlot.GapH = 0.05;   % ��ͼ֮������¼��
TightPlot.MarginsLower = 0.16;   % ��ͼ��ͼƬ�·��ļ��
TightPlot.MarginsUpper = 0.13;  % ��ͼ��ͼƬ�Ϸ��ļ��
TightPlot.MarginsLeft = 0.24;   % ��ͼ��ͼƬ�󷽵ļ��
TightPlot.MarginsRight = 0.41;  % ��ͼ��ͼƬ�ҷ��ļ��

%% PLOT
figure(1);  % ����Figure
p = tight_subplot(TightPlot.ColumeNumber,TightPlot.RowNumber,...
    [TightPlot.GapH TightPlot.GapW],...
    [TightPlot.MarginsLower TightPlot.MarginsUpper],...
    [TightPlot.MarginsLeft TightPlot.MarginsRight]);    % �������ò�����һ���Ѿ�������

load MRERK2.mat 
ERR_MRERK2=ERR(2:end);  TIME_MRERK2=TIME(2:end);
load IMEXSP2.mat 
ERR_MRIERK2=ERR(2:end);  TIME_MRIERK2=TIME(2:end);
load MRERK3.mat
ERR_MRERK3=ERR(2:end);  TIME_MRERK3=TIME(2:end);
load IMEXSP3.mat
ERR_MRIERK3=ERR(2:end);  TIME_MRIERK3=TIME(2:end);
load MRERK4.mat
ERR_MRERK4=ERR(2:end);  TIME_MRERK4=TIME(2:end);
load IMEXSP4.mat
ERR_MRIERK4=ERR(2:end);  TIME_MRIERK4=TIME(2:end);

loglog(TIME_MRIERK2,ERR_MRIERK2,'--bD','LineWidth',2,'MarkerSize',10);  hold on;
loglog(TIME_MRIERK3,ERR_MRIERK3,'--go','LineWidth',2,'MarkerSize',10);
loglog(TIME_MRIERK4,ERR_MRIERK4,'--rs','LineWidth',2,'MarkerSize',10);
loglog(TIME_MRERK2,ERR_MRERK2,'-bD','LineWidth',2,'MarkerSize',10,'Markerfacecolor','b'); 
loglog(TIME_MRERK3,ERR_MRERK3,'-go','LineWidth',2,'MarkerSize',10,'Markerfacecolor','g');  
loglog(TIME_MRERK4,ERR_MRERK4,'-rs','LineWidth',2,'MarkerSize',10,'Markerfacecolor','r');
grid on;

set(gca,'XLim',[0.006 0.15])
set(gca,'YLim',[10^(-9) 10^(-1)]);
set(gca,'ytick',[10^(-9) 10^(-7) 10^(-5) 10^(-3) 10^(-1)]); % set(gca,'yticklabel',{})     
set(gca,'linewidth',2,'FontSize',24)
xlabel('CPU time','interpreter','latex','FontSize',32)
ylabel('$L^\infty$-error','interpreter','latex','FontSize',32)
legend('IMEXSP(2)','IMEXSP(3)','IMEXSP(4)','MRERK2','MRERK3','MRERK4')
% legend('IMEXSP(2)','IMEXSP(3)','MRERK2','MRERK3')
set(legend,'interpreter','latex','location','southwest','FontSize',20) 