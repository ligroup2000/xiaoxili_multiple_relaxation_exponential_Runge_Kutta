function [err,energy1_average,energy2_average,time]=IMEXSP4(tau)
tic;
N=500;  T=1;  Le=-25;  Re=25;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  
Ue=@(t)sech(xmesh+4*t).*exp(-1i*(2*xmesh+3*t));
Un=Ue(tn);
Un_t=fftcoe*fft(Un); 
Energy1=[];  Energy2=[];

Ai=[0 0 0 0 0 0; ... 
    0 1/2 0 0 0 0; ...
    1/4 -1/4 1/2 0 0 0; ...
    0 1 0 0 0 0; ...
    1/6 0 2/3 -4/3 3/2 0; ...
    1/6 0 2/3 1/6 -2 2;];
Ae=[0 0 0 0 0 0; ...
    1/2 0 0 0 0 0; ...
    1/4 1/4 0 0 0 0; ...
    0 -1 2 0 0 0; ...
    1/6 0 2/3 1/6 0 0; ...
    1/6 0 2/3 1/6 0 0;];
Matrix1=(ones(N,1)-tau*0.5*L).^(-1);  Matrix2=(ones(N,1)-tau*(3/2)*L).^(-1);  Matrix3=(ones(N,1)-tau*2*L).^(-1);  
s=size(Ai,2);

Umid=zeros(N,s);  F1mid=zeros(N,s);  F2mid=zeros(N,s);  
for k=1:round(T/tau)
    Umid(:,1)=Un_t;  
    F1mid(:,1)=L.*Umid(:,1);  
    Umid_temp=ifftcoe*ifft(Umid(:,1));  F2mid(:,1)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,1:1);  F1midp=tau*F1midp*(Ai(2,1:1))';
    F2midp=F2mid(:,1:1);  F2midp=tau*F2midp*(Ae(2,1:1))';
    Umid(:,2)=Matrix1.*(Un_t+F1midp+F2midp);
    F1mid(:,2)=L.*Umid(:,2);  
    Umid_temp=ifftcoe*ifft(Umid(:,2));  F2mid(:,2)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,1:2);  F1midp=tau*F1midp*(Ai(3,1:2))';
    F2midp=F2mid(:,1:2);  F2midp=tau*F2midp*(Ae(3,1:2))';
    Umid(:,3)=Matrix1.*(Un_t+F1midp+F2midp);
    F1mid(:,3)=L.*Umid(:,3);  
    Umid_temp=ifftcoe*ifft(Umid(:,3));  F2mid(:,3)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,1:3);  F1midp=tau*F1midp*(Ai(4,1:3))';
    F2midp=F2mid(:,1:3);  F2midp=tau*F2midp*(Ae(4,1:3))';
    Umid(:,4)=Un_t+F1midp+F2midp;
    F1mid(:,4)=L.*Umid(:,4);  
    Umid_temp=ifftcoe*ifft(Umid(:,4));  F2mid(:,4)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,1:4);  F1midp=tau*F1midp*(Ai(5,1:4))';
    F2midp=F2mid(:,1:4);  F2midp=tau*F2midp*(Ae(5,1:4))';
    Umid(:,5)=Matrix2.*(Un_t+F1midp+F2midp);
    F1mid(:,5)=L.*Umid(:,5);  
    Umid_temp=ifftcoe*ifft(Umid(:,5));  F2mid(:,5)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    
    F1midp=F1mid(:,1:5);  F1midp=tau*F1midp*(Ai(6,1:5))';
    F2midp=F2mid(:,1:5);  F2midp=tau*F2midp*(Ae(6,1:5))';
    Umid(:,6)=Matrix3.*(Un_t+F1midp+F2midp);
    F1mid(:,6)=L.*Umid(:,6);  
    Umid_temp=ifftcoe*ifft(Umid(:,6));  F2mid(:,6)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
      
    Unew_t=Umid(:,end);  
    energy1=area*real(sum(conj(Un_t).*Un_t)); 
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  
    Energy1=[Energy1 energy1];  Energy2=[Energy2 energy2];
    %%%% step update %%%%
    Un_t=Unew_t;  tn=tn+tau;
end

toc;
time=toc;
energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
energy2_average=mean(abs(Energy2-Energy2(1))./abs(Energy2(1)));
err=max(abs(Un_t-fftcoe*fft(Ue(T))));