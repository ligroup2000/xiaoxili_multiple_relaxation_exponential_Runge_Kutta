for kkk=1:3
stepsize=[1/10 1/20 1/40 1/80 1/160];  num=20;
ERR=[];  TIME=[];  ENERGY1=[];  ENERGY2=[];
for k=1:size(stepsize,2)
    err_all=[];  energy1_average_all=[];  energy2_average_all=[];  time_all=[];
    for kk=1:num+2
        [err,energy1_average,energy2_average,time]=IMEXSP2(stepsize(k));
        err_all=[err_all err];
        energy1_average_all=[energy1_average_all energy1_average];
        energy2_average_all=[energy2_average_all energy2_average];
        time_all=[time_all time];
    end
    err_all=err_all(3:end);
    energy1_average_all=energy1_average_all(3:end);
    energy2_average_all=energy2_average_all(3:end);
    time_all=time_all(3:end);
    ERR=[ERR mean(err_all)];
    ENERGY1=[ENERGY1 mean(energy1_average_all)];
    ENERGY2=[ENERGY2 mean(energy2_average_all)];
    TIME=[TIME mean(time_all)];
end
Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
save('IMEXSP2.mat');

stepsize=[1/10 1/20 1/40 1/80 1/160];  num=20;
ERR=[];  TIME=[];  ENERGY1=[];  ENERGY2=[];
for k=1:size(stepsize,2)
    err_all=[];  energy1_average_all=[];  energy2_average_all=[];  time_all=[];
    for kk=1:num+2
        [err,energy1_average,energy2_average,time]=IMEXSP3(stepsize(k));
        err_all=[err_all err];
        energy1_average_all=[energy1_average_all energy1_average];
        energy2_average_all=[energy2_average_all energy2_average];
        time_all=[time_all time];
    end
    err_all=err_all(3:end);
    energy1_average_all=energy1_average_all(3:end);
    energy2_average_all=energy2_average_all(3:end);
    time_all=time_all(3:end);
    ERR=[ERR mean(err_all)];
    ENERGY1=[ENERGY1 mean(energy1_average_all)];
    ENERGY2=[ENERGY2 mean(energy2_average_all)];
    TIME=[TIME mean(time_all)];
end
Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
save('IMEXSP3.mat');

stepsize=[1/10 1/20 1/40 1/80 1/160];  num=20;
ERR=[];  TIME=[];  ENERGY1=[];  ENERGY2=[];
for k=1:size(stepsize,2)
    err_all=[];  energy1_average_all=[];  energy2_average_all=[];  time_all=[];
    for kk=1:num+2
        [err,energy1_average,energy2_average,time]=IMEXSP4(stepsize(k));
        err_all=[err_all err];
        energy1_average_all=[energy1_average_all energy1_average];
        energy2_average_all=[energy2_average_all energy2_average];
        time_all=[time_all time];
    end
    err_all=err_all(3:end);
    energy1_average_all=energy1_average_all(3:end);
    energy2_average_all=energy2_average_all(3:end);
    time_all=time_all(3:end);
    ERR=[ERR mean(err_all)];
    ENERGY1=[ENERGY1 mean(energy1_average_all)];
    ENERGY2=[ENERGY2 mean(energy2_average_all)];
    TIME=[TIME mean(time_all)];
end
Order=log(ERR(1:end-1)./ERR(2:end))./log(stepsize(1:end-1)./stepsize(2:end));
save('IMEXSP4.mat');
end