function [err,energy1_average,energy2_average,time]=IMEXSP2(tau)
tic;
N=500;  T=1;  Le=-25;  Re=25;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  
Ue=@(t)sech(xmesh+4*t).*exp(-1i*(2*xmesh+3*t));
Un=Ue(tn);
Un_t=fftcoe*fft(Un); 
Energy1=[];  Energy2=[];

Ai=[0 0;0 1/2];
bi1=[0 1];
Ae=[0 0;1/2 0];
be1=[0 1];
Matrix=(ones(N,1)-tau*0.5*L).^(-1);  s=size(Ai,2);

Umid=zeros(N,s);  F1mid=zeros(N,s);  F2mid=zeros(N,s);  
for k=1:round(T/tau)
    Umid(:,1)=Un_t;  
    F1mid(:,1)=L.*Umid(:,1);  
    Umid_temp=ifftcoe*ifft(Umid(:,1));  F2mid(:,1)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    for kk=2:s
        F1midp=F1mid(:,1:kk-1);  F1midp=tau*F1midp*(Ai(kk,1:kk-1))';
        F2midp=F2mid(:,1:kk-1);  F2midp=tau*F2midp*(Ae(kk,1:kk-1))';
        Umid(:,kk)=Matrix.*(Un_t+F1midp+F2midp);
        F1mid(:,kk)=L.*Umid(:,kk);  
        Umid_temp=ifftcoe*ifft(Umid(:,kk));  F2mid(:,kk)=fftcoe*fft(1i*(f(abs(Umid_temp).^2).*Umid_temp));
    end
    d1_t=tau*F1mid*bi1'+tau*F2mid*be1';
    Unew_t=Un_t+d1_t;  
    energy1=area*real(sum(conj(Un_t).*Un_t)); 
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  
    Energy1=[Energy1 energy1];  Energy2=[Energy2 energy2];
    %%%% step update %%%%
    Un_t=Unew_t;  tn=tn+tau;
end

toc;
time=toc;
energy1_average=mean(abs(Energy1-Energy1(1))./abs(Energy1(1)));
energy2_average=mean(abs(Energy2-Energy2(1))./abs(Energy2(1)));
err=max(abs(Un_t-fftcoe*fft(Ue(T))));