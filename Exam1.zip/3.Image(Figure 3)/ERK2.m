function [U_save,tmesh,xmesh]=ERK2(tau)

N=2000;  T=20;  Le=-100;  Re=100;  p=1;  alpha=2;
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0;  Un=sech(xmesh).*exp(-2*1i*xmesh);
Un_t=fftcoe*fft(Un); 
U_save=[];  tmesh=[];

c2=0.5;
tauL=tau*L;  tauL2=c2*tauL;
tauL(1)=1;  tauL2(1)=1;
%%%%  tauL  %%%%
phi1=(exp(tauL)-1)./(tauL);  phi1(1,1)=1;
phi2=(exp(tauL)-1-tauL)./(tauL.^2);  phi2(1,1)=1/2;
phi3=(exp(tauL)-1-tauL-(1/2)*tauL.^2)./(tauL.^3);  phi2(1,1)=1/6;
phi4=(exp(tauL)-1-tauL-(1/2)*tauL.^2-(1/6)*tauL.^3)./(tauL.^4);  phi2(1,1)=1/24;
%%%%  tauL2  %%%%
phi12=(exp(tauL2)-1)./(tauL2);  phi12(1,1)=1;
%%%%  coe_matrix %%%%
A21=c2*phi12;
B1=phi1-(1/c2)*phi2;  B2=(1/c2)*phi2;

while (tn<(T-tau))
    %%%% Un1_t %%%%
    LUn_t=L.*Un_t;  Un1_t=Un_t;
    %%%% Un2_t %%%%
    Un1=ifftcoe*ifft(Un1_t);  Gn1_t=fftcoe*fft(1i*(f(abs(Un1).^2).*Un1));  GLUn1_t=Gn1_t+LUn_t;
    Un2_t=Un_t+tau*A21.*GLUn1_t;
    %%%% Unew_t %%%%
    Un2=ifftcoe*ifft(Un2_t);  Gn2_t=fftcoe*fft(1i*(f(abs(Un2).^2).*Un2));  GLUn2_t=Gn2_t+LUn_t;
    d1_t=tau*B1.*GLUn1_t+tau*B2.*GLUn2_t;
    Unew_t=Un_t+d1_t;
    energy1=area*real(sum(conj(Un_t).*Un_t)); 
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  
    tmesh=[tmesh tn];  U_save=[U_save abs(ifftcoe*ifft(Un_t))];
    Un_t=Unew_t;  tn=tn+tau
    plot(xmesh,abs(ifftcoe*ifft(Un_t)));  drawnow;
end

save('ERK2.mat','U_save','tmesh','xmesh');