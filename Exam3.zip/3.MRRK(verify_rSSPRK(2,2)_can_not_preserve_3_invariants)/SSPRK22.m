function [Energy1,Energy2,Energy3,tmesh,time,Iter,DET]=SSPRK22(tau)
tic;

N=100;  T=100;  Le=0;  Re=2*pi;  p=0;  alpha=1; 
h=(Re-Le)/N;  area=Re-Le;  xmesh=Le:h:Re-h;  xmesh=xmesh';  freq=(2*pi/(Re-Le))*[0:N/2-1 -N/2:-1];  freq=freq';
Kxx=(-1)*freq.^2;  ImKx=freq;  L=1i*Kxx;
f=@(x)alpha*x.^p;  F=@(x)(alpha/(p+1))*x.^(p+1);
fftcoe=1/N;  ifftcoe=N;
tn=0; 
Un=3*(sin(xmesh)+1i*(cos(xmesh)).^2).*exp(1i*xmesh);  Un_t=fftcoe*fft(Un);
Energy1=[];  Energy2=[];  Energy3=[];  tmesh=[];  Iter=[];  DET=[];

A=[0 0;1 0];
b1=[1/2 1/2];
b2=[1/3 2/3];
b3=[0 1];
s=size(A,2);

while (tn<(T-tau))
    Umid=zeros(N,s);  Fmid=zeros(N,s);  
    Umid(:,1)=Un_t;  Un=ifftcoe*ifft(Un_t);  Fmid(:,1)=L.*Un_t+fftcoe*fft(1i*(f(abs(Un).^2).*Un));
    for kk=2:s
        Umid(:,kk)=Un_t+tau*Fmid(:,1:kk-1)*(A(kk,1:kk-1))';
        Up=ifftcoe*ifft(Umid(:,kk));
        Fmid(:,kk)=L.*Umid(:,kk)+fftcoe*fft(1i*(f(abs(Up).^2).*Up));
    end
    d1_t=tau*Fmid*b1';  d1=ifftcoe*ifft(d1_t);
    d2_t=tau*Fmid*b2';  d2=ifftcoe*ifft(d2_t);
    d3_t=tau*Fmid*b3';  d3=ifftcoe*ifft(d3_t);
    Unew_t=Un_t+d1_t;  Unew=ifftcoe*ifft(Unew_t);  
    energy1=area*real(sum(conj(Un_t).*Un_t));  Energy1=[Energy1 energy1];
    energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy2=[Energy2 energy2];
    energy3=area*real(sum(conj(Un_t).*ImKx.*Un_t));  Energy3=[Energy3 energy3];  tmesh=[tmesh tn];
    %%%% compute gamma %%%%
    if ( sum(sum(abs(d1_t)))==0 )
        gamma=[0;0;0];
    else
        conjUnew_t=conj(Unew_t);  conjd1=conj(d1_t);  conjd2=conj(d2_t);  conjd3=conj(d3_t);
        UnewUn=area*real(sum(conjUnew_t.*Unew_t))-energy1;  
        Unewd1=area*real(sum(conjUnew_t.*d1_t));  Unewd2=area*real(sum(conjUnew_t.*d2_t));  Unewd3=area*real(sum(conjUnew_t.*d3_t));  
        d1d1=area*real(sum(conjd1.*d1_t));  d2d2=area*real(sum(conjd2.*d2_t));  d3d3=area*real(sum(conjd3.*d3_t));  
        d1d2=area*real(sum(conjd1.*d2_t));  d1d3=area*real(sum(conjd1.*d3_t));  d2d3=area*real(sum(conjd2.*d3_t));
        UnewKUn=-area*real(sum(conjUnew_t.*Kxx.*Unew_t))-energy2;
        UnewKd1=-area*real(sum(conjUnew_t.*Kxx.*d1_t));  UnewKd2=-area*real(sum(conjUnew_t.*Kxx.*d2_t));  UnewKd3=-area*real(sum(conjUnew_t.*Kxx.*d3_t));
        d1Kd1=-area*real(sum(conjd1.*Kxx.*d1_t));  d2Kd2=-area*real(sum(conjd2.*Kxx.*d2_t));  d3Kd3=-area*real(sum(conjd3.*Kxx.*d3_t));  
        d1Kd2=-area*real(sum(conjd1.*Kxx.*d2_t));  d1Kd3=-area*real(sum(conjd1.*Kxx.*d3_t));  d2Kd3=-area*real(sum(conjd2.*Kxx.*d3_t));
        UnewIKUn=area*real(sum(conjUnew_t.*ImKx.*Unew_t))-energy3;  
        UnewIKd1=area*real(sum(conjUnew_t.*ImKx.*d1_t));  UnewIKd2=area*real(sum(conjUnew_t.*ImKx.*d2_t));  UnewIKd3=area*real(sum(conjUnew_t.*ImKx.*d3_t));  
        d1IKd1=area*real(sum(conjd1.*ImKx.*d1_t));  d2IKd2=area*real(sum(conjd2.*ImKx.*d2_t));  d3IKd3=area*real(sum(conjd3.*ImKx.*d3_t));  
        d1IKd2=area*real(sum(conjd1.*ImKx.*d2_t));  d1IKd3=area*real(sum(conjd1.*ImKx.*d3_t));  d2IKd3=area*real(sum(conjd2.*ImKx.*d3_t));
        [gamma,iter_count]=compute_gamma(f,Unew,d1,d2,d3,F,h,UnewUn,Unewd1,Unewd2,Unewd3,d1d1,d2d2,d3d3,d1d2,d1d3,d2d3, ...
                                          UnewKUn,UnewKd1,UnewKd2,UnewKd3,d1Kd1,d2Kd2,d3Kd3,d1Kd2,d1Kd3,d2Kd3, ...
                                          UnewIKUn,UnewIKd1,UnewIKd2,UnewIKd3,d1IKd1,d2IKd2,d3IKd3,d1IKd2,d1IKd3,d2IKd3);
        fUnew=f(abs(Unew).^2).*Unew;
        BB=[(2/tau/tau)*Unewd1 (2/tau/tau)*Unewd2 (2/tau/tau)*Unewd3; ...
            (2/tau/tau)*UnewKd1-(2/tau/tau)*real(h*sum(fUnew.*conj(d1))) ...
            (2/tau/tau)*UnewKd2-(2/tau/tau)*real(h*sum(fUnew.*conj(d2))) ...
            (2/tau/tau)*UnewKd3-(2/tau/tau)*real(h*sum(fUnew.*conj(d3))); ...
            (2/tau/tau)*UnewIKd1 (2/tau/tau)*UnewIKd2 (2/tau/tau)*UnewIKd3];
        DET=[DET det(BB)];
    end
    Iter=[Iter iter_count];
    %%%% step update %%%%
    Un_t=Unew_t+gamma(1)*d1_t+gamma(2)*d2_t+gamma(3)*d3_t;  tn=tn+(1+gamma(1)+gamma(2)+gamma(3))*tau
end
energy1=area*real(sum(conj(Un_t).*Un_t));  Energy1=[Energy1 energy1];
energy2=-area*real(sum(conj(Un_t).*Kxx.*Un_t))-h*sum(F((abs(ifftcoe*ifft(Un_t))).^2));  Energy2=[Energy2 energy2];
energy3=area*real(sum(conj(Un_t).*ImKx.*Un_t));  Energy3=[Energy3 energy3];  tmesh=[tmesh tn];
toc;  time=toc;

subplot(2,3,1)
plot(tmesh,abs(Energy1-Energy1(1))/abs(Energy1(1)));  drawnow;
subplot(2,3,2)
plot(tmesh,abs(Energy2-Energy2(1))/abs(Energy2(1)));  drawnow;
subplot(2,3,3)
plot(tmesh,abs(Energy3-Energy3(1))/abs(Energy3(1)));  drawnow;
subplot(2,3,4)
semilogy(tmesh(1:end-1),abs(DET));  drawnow;
subplot(2,3,5)
plot(tmesh(1:end-1),Iter);  drawnow;

save('SSPRK22.mat','Energy1','Energy2','Energy3','tmesh','time','Iter','DET');