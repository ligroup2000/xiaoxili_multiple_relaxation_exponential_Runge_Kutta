function [gamma,iter_count]=compute_gamma(f,Unew,d1,d2,F,h,UnewUn,Unewd1,Unewd2,d1d1,d2d2,d1d2, ...
                                          UnewKUn,UnewKd1,UnewKd2,d1Kd1,d2Kd2,d1Kd2)
iter_err=1;  iter_count=0;  gamma=[0;0];
while ( (iter_err > 10^(-14)) && (iter_count<10) )
    gamma1=gamma(1);  gamma2=gamma(2);
    Unext=Unew+gamma1*d1+gamma2*d2;  Unexts=abs(Unext).^2;
    vector=[UnewUn+2*gamma1*Unewd1+2*gamma2*Unewd2+gamma1^2*d1d1+gamma2^2*d2d2+2*gamma1*gamma2*d1d2;
            UnewKUn+2*gamma1*UnewKd1+2*gamma2*UnewKd2+gamma1^2*d1Kd1+gamma2^2*d2Kd2+2*gamma1*gamma2*d1Kd2-h*sum(F(Unexts));];
    matrix=[2*Unewd1+2*gamma1*d1d1+2*gamma2*d1d2 ...
            2*Unewd2+2*gamma1*d1d2+2*gamma2*d2d2; ...
            2*UnewKd1+2*gamma1*d1Kd1+2*gamma2*d1Kd2-2*h*sum(real(f(Unexts).*Unext.*conj(d1))) ...
            2*UnewKd2+2*gamma1*d1Kd2+2*gamma2*d2Kd2-2*h*sum(real(f(Unexts).*Unext.*conj(d2)));];
    gamma_save=gamma;  gamma=gamma-matrix\vector;
    iter_err=max(abs(gamma_save-gamma));  iter_count=iter_count+1;
end